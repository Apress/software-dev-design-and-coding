/*
 * example of a race condition
 * with Java Threads
 *  Here we are going to create two threads and have
 *  each of them withdraw $10 from the account
 *  10 times in a row.
 */
public class FredAndGladys implements Runnable  {
    private BankAccount account = new BankAccount();

    /** The run() method does the actual work of the thread */
    public void run()  {
        for (int x = 0; x < 10; x++) {
            makeWithdrawal(10);
            if (account.getBalance() < 0) {
                System.out.println("Overdrawn!");
            }
        }
    }

    /**
     *  The method that makes each withdrawal.
     *  It checks to see if the balance is OK
     *  goes to sleep for 500msec and then
     *  attempts to withdraw the money.
     * to fix the problem
     * make this a synchronized method
     */
    //private synchronized void makeWithdrawal(int amount) {
    private void makeWithdrawal(int amount)  {
        /** so we know which thread this is */
        String name = Thread.currentThread().getName();
        if (account.getBalance() >= amount)
        {
            System.out.println(name + " is about to withdraw " + amount);
            try {
                System.out.println(name + " is going to sleep");
                Thread.sleep(500);
            } catch (InterruptedException ex) {
                ex.printStackTrace();
            }

            System.out.println(name + " woke up");
            account.withdraw(amount);
            System.out.printf("%s completes the withdrawal\n", name);
            System.out.printf("New balance is $%d\n", account.getBalance());
        } else {
            System.out.println("Sorry, not enough for "
                        + Thread.currentThread().getName());
        }
    }
}

/**
 *  inner class to represent a simple bank account
 */
class BankAccount {
    private volatile int balance = 100;

    public int getBalance () {
        return balance;
    }

    public void withdraw(int amount) {
        balance = balance - amount;
    }
}

/**
 * the driver to run the experiment
 */
class FGMain
{
    public static void main(String[] args) {
        FredAndGladys theJob = new FredAndGladys();

        Thread one = new Thread(theJob);
        Thread two = new Thread(theJob);

        one.setName("Fred");
        two.setName("Gladys");

        one.start();
        two.start();
    }
}

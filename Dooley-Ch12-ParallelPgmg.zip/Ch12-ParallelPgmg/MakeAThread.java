/**
 * just about the simplest example of starting and running a Java Thread
 * This new thread will just print “MyThread is running” and exit.
 */

 public class MakeAThread {

    /** make an inner class that will be the new thread */
    public static class MyThread extends Thread {
        /** the Thread must have a run method */
        @Override
        public void run(){
            System.out.println("MyThread is running");
        }
    }

    public static void main(String [] args) {
        MyThread myThread = new MyThread();

        /** always start a new thread using the start() method */
        myThread.start();
    }
 }

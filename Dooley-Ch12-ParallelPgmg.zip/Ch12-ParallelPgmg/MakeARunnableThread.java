/**
 * a second way to
 * make a simple example of starting and running a Java Thread
 */

 public class MakeARunnableThread {

     /** make an inner class that will be the new thread */
    public static class MyRunnable implements Runnable {
        /** the Runnable must have a run method */
        @Override
        public void run(){
            System.out.println("MyRunnableThread is running");
        }
    }

    public static void main(String [] args) {
        Thread myThread = new Thread(new MyRunnable());

        /** always start a new thread using the start() method */
        myThread.start();
    }
 }

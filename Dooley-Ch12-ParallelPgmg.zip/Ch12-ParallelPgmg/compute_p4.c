/*
 *  Serial program to estimate the area under a curve f(x)
 *  It really computes pi/4 and approximates the trapezoidal rule
 *  using rectangles instead of trapezoids.
 *  July 2017
 */
 #include <stdio.h>
 #include <stdlib.h>

 /*
  * Here's the function we'll be computing
  */
 double f(double x) {
    return 1.0 / (1.0 + x * x);
 }

int main (int argc, char **argv) {
    int steps = 1000000000;     /* number of rectangles */
    double width = 0.0;             /* width of each rectangle */
    double x, pi4, sum = 0.0;

    /* get the width of each rectangle */
    width = 1.0 / (double) steps;

    /* loop to compute the area under f(x) */
    for (int i = 0; i <= steps; i++) {
        x = i * width;
        sum = sum + f(x);
    }
    pi4 = width * sum;
    printf("Sum is %8.4f and Area:pi/4 is %8.6f\n", sum, pi4);
    printf("Approximation to pi is %8.6f\n", pi4 * 4.0);
    return 0;
}

public class TestExceptions {
  public static void main(String[] args) {
      String str = null;
      int len = str.length();
  }
}


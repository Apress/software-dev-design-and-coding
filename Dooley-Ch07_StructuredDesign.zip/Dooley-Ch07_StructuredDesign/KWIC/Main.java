import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 * Manage the KWIC indexing system.
 * 
 * @author jfdooley
 *
 */

public class Main {

    public static void main(String[] args) {
		/**
		 * declare the Scanners to read the files
		 */
		Scanner scan = null;
		Scanner ignore = null;
		/**
		 * usage and file opening
		 *
		 * if we have the correct number of input args
		 * we try to open the input files
		 */
		if (args.length == 2) {
	    	try {
				scan = new Scanner(new File(args[0]));
				ignore = new Scanner(new File(args[1]));
	    	} catch (FileNotFoundException ex) {
				System.out.println(ex.getMessage());
				System.exit(1);
	    	}
		/**
		 * wrong number of input args. Give user a usage
		 * message and leave
		 */
		} else {
	    	System.out.println("Usage: java Main <inputFile> <wordsToIgnore>");
			System.exit(1);
		}

		/**
		 * first we create an KwicIndex object & add 
		 * the words to ignore to it
		 */
		KwicIndex index = new KwicIndex(ignore);

		/**
		 * Now we add all the lines to the index
		 * the add() method does the work of the circular shift
		 * and adding the shifted line to the priority queue
		 */
		while (scan.hasNextLine()) {
	    	index.add(scan.nextLine());
		}

		/**
		 * Finally we print the index we just created
		 */
		Print prt = new Print(index.getLines());
		prt.printIndex();
    }
}

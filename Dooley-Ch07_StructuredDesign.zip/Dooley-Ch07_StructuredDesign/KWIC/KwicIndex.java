import java.util.Scanner;
import java.util.*;

/**
 * An KwicIndex object contains a collection of Lines
 * and the words we are ignoring as keywords.
 *
 * We use a HashSet for the words to ignore because
 * we only ever want one of each of these words.
 *
 * We use a PriorityQueue for the lines because we
 * want to store them sorted by keywords and the PQ
 * does that for us automatically.
 * 
 * @author jfdooley 07/2017
 */

public class KwicIndex {
    public HashSet<String> wordsToIgnore;
    public PriorityQueue<Line> lines;

	/**
	 * Constructor that initializes the lists and
	 * reads all the words to ignore
	 */
    public KwicIndex(Scanner ignore) {
		this.wordsToIgnore = new HashSet<String>();
		this.lines = new PriorityQueue<Line>();

		while (ignore.hasNext()) {
			this.wordsToIgnore.add(ignore.next());
		}
    }

    /**
     * Create an entry in the index for the given line.
     * @param str; a string to examine
     * @return
     */
    //public boolean add(String str) {
    public void add(String str) {
		Scanner scan = new Scanner(str);

		int offset = 0;
		int words = -1;
		while (scan.hasNext()) {
			/** grab the next word */
	    	String temp = scan.next();
	    	words++;
			/** if this word is not to be ignored create a new line
			 *  with the line shifted with the new word removed
			 *  then add it to the list of lines
			 */
	    	if (!wordsToIgnore.contains(temp.toLowerCase())) {
				Line version = new Line(str, temp, offset + words);
				this.lines.add(version);
	    	}
	    	offset += temp.length();
		}
		//return true;
    }

	/*
	 * return the index so we can print it
	 */
	public PriorityQueue<Line> getLines() {
		return lines;
	}
}

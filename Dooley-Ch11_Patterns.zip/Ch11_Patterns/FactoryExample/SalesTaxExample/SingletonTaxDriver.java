
/**
 *  Use the SalesTaxFactory to get the object of concrete classes
 */
 import java.io.*;
 import java.util.Scanner;

  public class SingletonTaxDriver {

      public static void main(String args[])throws IOException {
         Scanner stdin = new Scanner(System.in);

         /* get the single SalesTaxFactory that we need */
         SingletonTaxFactory salesTaxFactory =
                                            SingletonTaxFactory.getInstance();
         
         System.out.print("Enter the location (boston/chicago/stlouis): ");
         String location= stdin.nextLine();

         System.out.print("Enter the dollar amount: ");
         double amount = stdin.nextDouble();

         SalesTax cityTax = salesTaxFactory.getTax(location);

         System.out.printf("Bill amount for %s of  $%6.2f is: ", location, amount);
         cityTax.getRate();
         cityTax.calculateTax(amount);
        }
    }

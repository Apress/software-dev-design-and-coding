
public class BostonTax extends SalesTax {
    public void getRate() {
        rate = 0.0875;
   }
}

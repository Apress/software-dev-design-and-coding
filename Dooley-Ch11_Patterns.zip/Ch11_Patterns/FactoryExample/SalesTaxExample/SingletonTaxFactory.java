
 public class SingletonTaxFactory  {
     /**
      * We'll just create one SalesTaxFactory using the Singleton pattern
      * To do that we need to make the constructor private and create a
      * variable to hold the reference to the SalesTaxFactory object.
      */
      // this is the instance that will hang around
        private static SingletonTaxFactory uniqueInstance;

        // the private constructor – can't be accessed from outside
        private SingletonTaxFactory() {
                // do stuff here to initialize the instance
        }

        // here's the static method we'll use to create the instance
        public static SingletonTaxFactory getInstance() {
                if (uniqueInstance == null) {
                        uniqueInstance = new SingletonTaxFactory();
                }
                return uniqueInstance;
        }
   /**
    * use getTax method to get object of type Tax
    */
     public SalesTax getTax(String location) {
          if(location == null) {
              return null;
          }

	      if(location.equalsIgnoreCase("boston")) {
              return new BostonTax();
          }    else if(location.equalsIgnoreCase("chicago")) {
              return new ChicagoTax();
          }    else if(location.equalsIgnoreCase("stlouis"))  {
              return new StLouisTax();
          }
          return null;
     }
}

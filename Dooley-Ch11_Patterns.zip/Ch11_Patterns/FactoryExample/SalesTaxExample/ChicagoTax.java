
public class ChicagoTax extends SalesTax {
       public void getRate() {
           rate = 0.075;
      }
 }

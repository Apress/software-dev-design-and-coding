
 public class StLouisTax extends SalesTax {
     public void getRate() {
         rate = 0.05;
    }
 }

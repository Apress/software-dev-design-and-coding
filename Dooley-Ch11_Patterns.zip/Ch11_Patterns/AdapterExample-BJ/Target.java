
/**
 * interface Target
 */

public interface Target
{
    /**
     * An example of a method header - replace this comment with your own
     * 
     * @param  y    a sample parameter for a method
     * @return        the result produced by sampleMethod 
     */
    int sampleMethod(int y);
}

public class Bulb implements Switch {
    public void switchOn() {
        System.out.println("BULB Switched ON");
    }
    
    public void switchOff() {
        System.out.println("BULB Switched OFF");
    }
}

/**
 *class Adaptee
 */
public class Adaptee
{
   public Adaptee() {
    }

    public int myMethod(int y)
    {
        return y * y;
    }
}


 public class StLouisTax extends Tax {
     public void getRate() {
         rate = 0.05;
    }
 }

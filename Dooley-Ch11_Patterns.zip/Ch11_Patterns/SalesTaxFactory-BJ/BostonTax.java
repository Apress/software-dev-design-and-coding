
public class BostonTax extends Tax {
    public void getRate() {
        rate = 0.0875;
   }
}

 public class SalesTaxFactory  {
   /**
    * use getTax method to get object of type Tax
    */
     public Tax getTax(String location) {

        if(location == null) {
            return null;
        }

	    if(location.equalsIgnoreCase("boston")) {
            return new BostonTax();
        }  else if(location.equalsIgnoreCase("chicago")) {
            return new ChicagoTax();
        }  else if(location.equalsIgnoreCase("stlouis"))  {
            return new StLouisTax();
        }

        return null;
   }
}

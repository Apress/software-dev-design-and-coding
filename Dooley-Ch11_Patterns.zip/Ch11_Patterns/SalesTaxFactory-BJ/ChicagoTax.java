
public class ChicagoTax extends Tax {
       public void getRate() {
           rate = 0.075;
      }
 }

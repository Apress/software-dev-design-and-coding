/** compute the delivery charge for an item */
public class Delivery {
    public String computeDelivery(String orderID, String location) {
        return "Delivery amount computed";
    }
}

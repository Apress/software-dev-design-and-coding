/** Check the Inventory for the item */
public class Inventory {
    public String checkInventory(String orderId) {
        /* code in here to check the database */
        return "Inventory checked";
    }
}

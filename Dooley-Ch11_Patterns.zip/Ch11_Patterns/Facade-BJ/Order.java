/**
 * Here's the Facade
 */
public class Order {
    private Payment pymt = new Payment();
    private Inventory inventory = new Inventory();
    private SalesTax salestax = new SalesTax();
    private Delivery deliver = new Delivery();

    /**
     *  This is the new interface for buying an item
     *  it incorporates all the different steps into a single
     *  method call
     */
    public void placeOrder(String itemID, String currency, String location, double rate) {
        String step1 = inventory.checkInventory(itemID);
        String step2 = pymt.computePayment(itemID, currency);
        String step3 = salestax.computeTax(itemID, rate);
        String step4 = deliver.computeDelivery(itemID, location);

        System.out.printf("%s\n", step1);
        System.out.printf("%s\n", step2);
        System.out.printf("%s\n", step3);
        System.out.printf("%s\n", step4);
       }

      /** add more methods here for performing other actions */

}

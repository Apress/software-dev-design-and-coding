/** compute the sales tax for an item */
public class SalesTax {
    public String computeTax(String orderID, double rate) {
        return "Tax computed";
    }
}

/**
 * Here's the client code.
 * Note how the Facade makes ordering something simple
 * by using it's interface
 */
public class Client {
       public static void main(String args[]){
         Order order = new Order();
         
         order.placeOrder("OR123456", "USD", "Chicago", 0.075);
         System.out.println("Order processing completed");
       }
}

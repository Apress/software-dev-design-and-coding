/** compute the payment for an item */
public class Payment {
    public String computePayment(String orderID, String currency) {
        return "Payment computed successfully";
    }
}

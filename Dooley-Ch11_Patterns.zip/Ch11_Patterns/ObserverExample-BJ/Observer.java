
/**
 * interface Observer
 */

public interface Observer
{
    public void update(int foo, String bar);
}

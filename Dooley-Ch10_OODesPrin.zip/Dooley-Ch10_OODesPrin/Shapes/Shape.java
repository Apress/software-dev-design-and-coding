
/**
 * Write a description of interface Shape here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */

public interface Shape {
    public double computeArea();

    public double computePerimeter();
}

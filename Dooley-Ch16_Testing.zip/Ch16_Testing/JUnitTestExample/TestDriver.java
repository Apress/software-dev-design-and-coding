
/**
 * class TestDriver.
 */
public class TestDriver
{
    public static void main(String [] args)
    {
        TstPhoneContact t1 = new TstPhoneContact();
        
        t1.testPhoneContactCreation();
        
        t1.testFileOpen();
    }
}

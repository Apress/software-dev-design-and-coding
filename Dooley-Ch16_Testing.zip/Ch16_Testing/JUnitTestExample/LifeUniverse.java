public class LifeUniverse
{
	private int theAnswer;

	public LifeUniverse() {
		this.theAnswer = 42;
	}

	public int UltimateQuestion() {
		return this.theAnswer;
	}
}
